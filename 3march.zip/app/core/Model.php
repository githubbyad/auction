<?php

namespace app\core;

trait Model
{

    use \app\core\Database;

    public function all(array $data = [], array $data_not = [], string $order_column = 'id', string $order_type = 'DESC', int $order_limit = 10, int $offset = 0)
    {

        $query = "select * from $this->table";

        if (!empty($data) || !empty($data_not)) {

            $query .= " where ";

            $keys = array_keys($data);
            foreach ($keys as $key) {
                $query .= "$key = :$key && ";
            }

            $keys_not = array_keys($data_not);
            foreach ($keys_not as $key) {
                $query .= "$key != :$key && ";
            }

            $query = trim($query, "&& ");
        }

        $query .= " ORDER BY $order_column $order_type";

        if ($order_limit != 0) {
            $query .= "  LIMIT $order_limit OFFSET $offset";
        }

        $data = array_merge($data, $data_not);
        $result = $this->query($query, $data);

        if (is_array($result) && count($result) > 0) {
            return $result;
        }

        return [];
    }


    public function pending_list()
    {

        $query = "SELECT 
                    c.name as customer_name ,SUM(o.sell_price) as pending_payment, c.id as customer_id
                    FROM `customers` c
                    JOIN `orders` o
                    ON c.id = o.customer_id
                    WHERE o.payment_status = 'Pending'    
                    GROUP BY c.name
                    ORDER BY pending_payment DESC";

        $result = $this->query($query);

        return $result;
    }


    public function total(array $data = [], array $data_not = [], $column_name = '*')
    {

        $query = "select count($column_name) as counts from $this->table";

        if (!empty($data) || !empty($data_not)) {

            $query .= " where ";

            $keys = array_keys($data);
            foreach ($keys as $key) {
                $query .= "$key = :$key && ";
            }

            $keys_not = array_keys($data_not);
            foreach ($keys_not as $key) {
                $query .= "$key != :$key && ";
            }

            $query = trim($query, "&& ");
        }

        $data = array_merge($data, $data_not);
        $result = $this->query($query, $data);

        return $result[0]->counts;
    }

    public function sumTotal(array $data = [], array $data_not = [], $column_name = '*')
    {

        $query = "select sum($column_name) as counts from $this->table";

        if (!empty($data) || !empty($data_not)) {

            $query .= " where ";

            $keys = array_keys($data);
            foreach ($keys as $key) {
                $query .= "$key = :$key && ";
            }

            $keys_not = array_keys($data_not);
            foreach ($keys_not as $key) {
                $query .= "$key != :$key && ";
            }

            $query = trim($query, "&& ");
        }

        $data = array_merge($data, $data_not);
        $result = $this->query($query, $data);

        return $result[0]->counts;
    }



    public function first($data = [], $data_not = [])
    {

        $query = "select * from $this->table";

        if (!empty($data) || !empty($data_not)) {

            $query .= " where ";

            $keys = array_keys($data);
            foreach ($keys as $key) {
                $query .= "$key = :$key && ";
            }

            $keys_not = array_keys($data_not);
            foreach ($keys_not as $key) {
                $query .= "$key != :$key && ";
            }

            $query = trim($query, "&& ");
        }

        $data = array_merge($data, $data_not);
        $result = $this->query($query, $data);

        return $result[0];
    }

    public function random($data = [], $data_not = [])
    {

        $query = "select * from $this->table";

        if (!empty($data) || !empty($data_not)) {

            $query .= " where ";

            $keys = array_keys($data);
            foreach ($keys as $key) {
                $query .= "$key = :$key && ";
            }

            $keys_not = array_keys($data_not);
            foreach ($keys_not as $key) {
                $query .= "$key != :$key && ";
            }

            $query = trim($query, "&& ");
        }

        $query .= " ORDER BY RAND() LIMIT 1";

        $data = array_merge($data, $data_not);

        $result = $this->query($query, $data);

        return $result[0];
    }

    public function where($data, $data_not = [], string $order_column = 'id', string $order_type = 'DESC', int $order_limit = 10)
    {

        $query = "select * from $this->table";

        if (!empty($data) || !empty($data_not)) {

            $query .= " where ";

            $keys = array_keys($data);
            foreach ($keys as $key) {
                $query .= "$key = :$key && ";
            }

            $keys_not = array_keys($data_not);
            foreach ($keys_not as $key) {
                $query .= "$key != :$key && ";
            }

            $query = trim($query, "&& ");
        }

        $query .= " ORDER BY $order_column $order_type";

        if ($order_limit != 0) {
            $query .= "  LIMIT $order_limit";
        }

        $data = array_merge($data, $data_not);
        $result = $this->query($query, $data);

        return $result;
    }

    public function where_interval($data, $data_not = [], $column_name, $inverval)
    {
        $query = "SELECT * FROM $this->table WHERE ";

        $keys = array_keys($data);
        foreach ($keys as $key) {
            $query .= "$key = :$key && ";
        }

        $keys_not = array_keys($data_not);
        foreach ($keys_not as $key) {
            $query .= "$key != :$key && ";
        }

        $query .= "$column_name between date_sub(now(),INTERVAL $inverval) and now()";
        $query = trim($query, " && ");

        $data = array_merge($data, $data_not);

        return $this->query($query, $data);
    }


    public function where_like(array $data, string $order_column = 'id', string $order_type = 'DESC', int $order_limit = 10)
    {

        $query = "select * from $this->table where ";

        $keys = array_keys($data);
        foreach ($keys as $key) {
            $query .= "$key like :$key && ";
        }

        $query = trim($query, "&& ");

        $query .= " ORDER BY $order_column $order_type";

        if ($order_limit != 0) {
            $query .= "  LIMIT $order_limit";
        }

        $result = $this->query($query, $data);

        return $result;
    }

    public function insert($data)
    {

        // remove unwanted data
        if (!empty($this->allowedColumns)) {
            foreach ($data as $key => $value) {
                if (!in_array($key, $this->allowedColumns)) {
                    unset($data[$key]);
                }
            }
        }
        $keys = array_keys($data);
        $query = "insert into $this->table (" . implode(",", $keys) . ") values (:" . implode(",:", $keys) . ")";

        return $this->query($query, $data, 'insert');
    }

    public function update($id, $data, $id_column = 'id')
    {

        // remove unwanted data
        if (!empty($this->allowedColumns)) {
            foreach ($data as $key => $value) {
                if (!in_array($key, $this->allowedColumns)) {
                    unset($data[$key]);
                }
            }
        }
        $query = "update $this->table set ";

        unset($data[$id_column]); // removing key as we are not updating it

        $keys = array_keys($data);
        foreach ($keys as $key) {
            $query .= "$key = :$key, ";
        }
        $query = trim($query, ", ");

        $query .= " where  $id_column=:$id_column";

        $data[$id_column] = $id;

        return $this->query($query, $data, 'update');
    }

    public function delete($id, $id_column = 'id')
    {

        $query = "delete from $this->table where  $id_column=:$id_column";

        $data[$id_column] = $id;

        return $this->query($query, $data);
    }
}
