<?php

namespace app\core;

trait Database
{

    private function connect()
    {

        $dsn = DB_TYPE . ":host=" . DB_HOST . ";dbname=" . DB_NAME . ";";
        try {
            $conn = new \PDO($dsn, DB_USER, DB_PASS);
        } catch (\PDOException $e) {
            die("CONNECTION ERROR: " . $e->getMessage());
        }
        return $conn;
    }

    public function query($query, $data = [], $type = null)
    {

        $conn = $this->connect();

        $stm = $conn->prepare($query);
        try {

            $check = $stm->execute($data);
            if ($check) {

                if ($type != 'insert') {
                    
                    $result = $stm->fetchAll(\PDO::FETCH_OBJ);
                    if (is_array($result) && count($result) > 0) {

                        return $result;
                    }
                }
                return true;
            }
        } catch (\PDOException $e) {

            die("QUERY FAILED: " . $e->getMessage());
        }
        return false;
    }
}
