<?php

define('BAT', ROOT . '/public/assets/images/files/bat.png');

define('BALL', ROOT . '/public/assets/images/files/ball.png');

define('ALL', ROOT . '/public/assets/images/files/bat_and_ball.png');

define('KEEPER', ROOT . '/public/assets/images/files/wicket_keeping.png');

define('SOLD_YELLOW', ROOT . '/public/assets/images/files/sold_yellow.png');

define('SOLD_RED', ROOT . '/public/assets/images/files/sold_red.png');

define('UNDSOLD_RED', ROOT . '/public/assets/images/files/unsold_red.png');

define('DESIGNED_BY', ROOT . '/public/assets/images/files/designed_by.png');