<?php

defined("ROOTPATH") or die("Access Denied!");

define("FOLDER", "auction");

define('APP','Auction');

if ($_SERVER['SERVER_NAME'] == "localhost") { // localhost

    define("ROOT", "http://localhost/" . FOLDER);
    define("ASSETS", ROOT . "/public/assets");
    define("WEBSITE_NAME", "Localhost");

    // database details
    define("DB_TYPE", "mysql");
    define("DB_HOST", "localhost");
    define("DB_NAME", "auction");
    define("DB_USER", "root");
    define("DB_PASS", "");
} else { // live site

    define("ROOT", "https://www.mywebsite.com");
    define("ASSETS", ROOT . "/public/assets");
    define("WEBSITE_NAME", "My Website");

    // database details
    define("DB_TYPE", "mysql");
    define("DB_HOST", "localhost");
    define("DB_NAME", "auction");
    define("DB_USER", "root");
    define("DB_PASS", "");
}

// set to false hide errors, true to show errors
define("DEBUG", true);

// error reporting status
DEBUG ? ini_set("error_reporting", 1) : ini_set("error_reporting", 0);

// default timezone
date_default_timezone_set('Asia/Kolkata');
