<?php

namespace app\core;

class App
{

    // properties
    private $controller = 'home'; // default controller
    private $method     = 'index'; // default method

    // methods    
    public function __construct()
    {

        // get server url
        $url = $this->split_url();

        // load controller file
        $filename = 'app/controllers/' . ucfirst($url[0]) . '.php';

        if (file_exists($filename)) {

            $this->controller = ucfirst($url[0]); // get controller name    
            unset($url[0]); // removing from array as we got controller name
        } else {

            // load '_404' controller if not found
            $filename = 'app/controllers/_404.php';
            $this->controller = '_404';
        }
        require $filename;

        // get method          
        $class_path = '\\app\\controllers\\' . $this->controller;
        $obj = new $class_path; // creating instance for next step
        if (!empty($url[1])) {
            if (method_exists($obj, $url[1])) {
                $this->method = $url[1];
                unset($url[1]); // removing from array as we got method
            }
        }

        // call to controller        
        call_user_func_array([$obj, $this->method], $url);
    }

    // split url and convert into an array
    private function split_url()
    {

        // get the url from the server
        $url = $_GET['url'] ?? 'home';

        // remove any unwanted trailing slashes
        $url = trim($url, '/');

        // split URL into segments
        $result = explode('/', $url);

        return $result;
    }
}
