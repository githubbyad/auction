<?php

defined("ROOTPATH") or die("Access Denied!");

function show($stuff)
{

    echo '<pre>';
    print_r($stuff);
    echo '</pre>';
}

function moneyFormatIndia($num)
{
    $explrestunits = "";
    if (strlen($num) > 3) {
        $lastthree = substr($num, strlen($num) - 3, strlen($num));
        $restunits = substr($num, 0, strlen($num) - 3); // extracts the last three digits
        $restunits = (strlen($restunits) % 2 == 1) ? "0" . $restunits : $restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
        $expunit = str_split($restunits, 2);
        for ($i = 0; $i < sizeof($expunit); $i++) {
            // creates each of the 2's group and adds a comma to the end
            if ($i == 0) {
                $explrestunits .= (int)$expunit[$i] . ","; // if is first value , convert into integer
            } else {
                $explrestunits .= $expunit[$i] . ",";
            }
        }
        $thecash = $explrestunits . $lastthree;
    } else {
        $thecash = $num;
    }
    return $thecash; // writes the final format where $currency is the currency symbol.
}

function today()
{
    return date("d-m-Y");
}

function redirect_page($page)
{

    header("Location: $page");
    die();
}

function response($class_name, $message)
{
    $_SESSION['message']['text'] = $message;
    $_SESSION['message']['status'] = $class_name;
}


function admin()
{

    if (isset($_SESSION[APP]['username'])) {
        return true;
    }
    return false;
}


function get_firstname($name)
{
    $result = $name;
    $names = explode(' ', trim($name)); // converting text into array
    if (count($names) > 1) {
        unset($names[count($names) - 1]);

        $result = implode(' ', $names);
    }
    return $result;
}


function get_lastname($name)
{
    $names = explode(' ', trim($name)); // converting text into array
    $result = $names[count($names) - 1];
    return $result;
}


function upload_photo($file, $name, $folder, $maxWidth = '300')
{

    $status = [];

    // Define the target directory to upload the image
    $targetDir = 'public/assets/images/' . $folder . '/';

    // Get the file name and path
    $fileName = basename($file["name"]);
    $FilePath = $targetDir . $fileName;

    // Get the file extension
    $fileType = strtolower(pathinfo($FilePath, PATHINFO_EXTENSION));

    // updated file path
    $dateTime = date('dM_his_A');
    $savedFileName = strtolower(get_firstname($name)) . '_' . $dateTime  . "." . $fileType;
    $targetFilePath = $targetDir  . $savedFileName;

    show($savedFileName);
    // Check if the file is a valid image
    $allowedTypes = array('jpg', 'jpeg', 'png');
    if (in_array($fileType, $allowedTypes)) {

        // Upload the image
        if (move_uploaded_file($file["tmp_name"], $targetFilePath)) {

            // Resize the image
            list($width, $height) = getimagesize($targetFilePath);
            $newWidth = $maxWidth; // Set your desired width
            $newHeight = ($height / $width) * $newWidth;
            $resizedImage = imagecreatetruecolor($newWidth, $newHeight);

            if ($fileType == "jpg" || $fileType == "jpeg") {
                $sourceImage = imagecreatefromjpeg($targetFilePath);
                imagecopyresampled($resizedImage, $sourceImage, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
                imagejpeg($resizedImage, $targetFilePath, 80);
            } elseif ($fileType == "png") {
                $sourceImage = imagecreatefrompng($targetFilePath);
                imagealphablending($resizedImage, false);
                imagesavealpha($resizedImage, true);
                imagecopyresampled($resizedImage, $sourceImage, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
                imagepng($resizedImage, $targetFilePath, 9);
            }

            // Clean up resources
            imagedestroy($sourceImage);
            imagedestroy($resizedImage);

            $status['uploaded_path'] = $savedFileName;
        } else {
            $status['error'] = "Error uploading the image.";
        }
    } else {
        $status['error'] = "Invalid file type. Allowed types: jpg, jpeg, png.";
    }
    return $status;
}
