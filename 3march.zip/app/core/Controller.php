<?php

namespace App\core;

// prevent direct access to file
defined("ROOTPATH") OR die("Access Denied!");

Trait Controller {

    public function view($name, $data = []) {   

        extract($data);

        $filename = "app/views/" . strtolower($name) . ".view.php";

        if(file_exists($filename)) {
            require $filename; // load view file
        } else {
            require "app/views/404.view.php"; // load 404 file if not found 
        }

    }

}