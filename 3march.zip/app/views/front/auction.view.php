<?php //show($team); 
$playerX = new \app\models\Player;
?>

<!doctype html>
<html lang="en">

<head>

    <title><?= $title ?></title>
    <link rel="shortcut icon" href="<?= ROOT . '/public/assets/images/' . $setting->favicon . '?v=' . $updated ?>" type="image/x-icon">

    <!-- meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="og:type" content="website">
    <meta name="twitter:title" content="<?= $title ?>">
    <meta name="og:title" content="<?= $setting->title ?>">
    <meta name="og:description" content="It's Auction Time! Get all information about the auction as it happened. Details about Highest Bid for players, most expensive players, players retained, Teams &amp; their formations!">
    <meta name="keywords" content="auction, cricket auction, cricket ground, limited over cricket" />
    <meta name="description" content="It's Auction Time! Get all information about the auction as it happened. Details about Highest Bid for players, most expensive players, Teams &amp; their formations!" />
    <meta name="og:image" content="<?= ROOT . '/public/assets/images/' . $setting->sharing_image . '?v=' . $updated ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />

    <!--bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <!--custom css-->
    <link rel="stylesheet" type="text/css" href="<?= ROOT ?>/public/assets/css/style.css?v=<?= $updated ?>">

    <!--custom js--->
    <script src="<?= ROOT ?>/public/assets/js/functions.js?v=<?= $updated ?>"></script>
</head>

<body class="auction_body px-0">

    <div class="auction-body">

        <!-- loader -->
        <div class="loader">
            <div class="dots">
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
            </div>
        </div>
        <!-- /loader -->

    </div>

    <!-- wrapper -->
    <div class="auction-wrapper invisible">
        <style>
            /* @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@700&display=swap');
            @import url('https://fonts.googleapis.com/css2?family=Sen:wght@800&display=swap'); */

            body {
                background-image: url("<?= ROOT . '/public/assets/images/files/auction_background.jpg?v=' . $updated ?>");
            }
            .modal-dialog {
                max-width: 50% !important;
            }
        </style>

        <!-- go-back -->
        <span class="go_back_auction text-center" onclick="history.back()">
            <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" fill="currentColor" class="bi bi-chevron-left bg-white text-black rounded-pill p-2" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0" />
            </svg>
            <b class="text-white fs-6">BACK</b>
        </span>
        <!-- /go-back -->

        <!-- reset player -->
        <span class="reset_player text-center">
            <a href="<?= ROOT . '/auction/reset/' . $player->id ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" fill="currentColor" class="bi bi-arrow-clockwise bg-light rounded-pill p-2" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2v1z" />
                    <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466z" />
                </svg>
                <b class="text-white fs-6 fw-bold">RESET</b>
            </a>
        </span>
        <!-- /reset player -->

        <!-- balance left -->
        <span class="balance_left text-center" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
            <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" fill="currentColor" class="bi bi-currency-rupee bg-light rounded-pill p-2" viewBox="0 0 16 16">
                <path d="M4 3.06h2.726c1.22 0 2.12.575 2.325 1.724H4v1.051h5.051C8.855 7.001 8 7.558 6.788 7.558H4v1.317L8.437 14h2.11L6.095 8.884h.855c2.316-.018 3.465-1.476 3.688-3.049H12V4.784h-1.345c-.08-.778-.357-1.335-.793-1.732H12V2H4z" />
            </svg>
            <b class="text-white fs-6 fw-bold">BALANCE LEFT</b>
        </span>
        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header bg-warning">
                        <h1 class="modal-title fw-bold text-black text-center fs-1 w-100" id="staticBackdropLabel">TEAM STATUS</h1>
                        <button type="button" class="btn-close opacity-1" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body fs-2 text-uppercase">
                        <table class="team_table table table-borderless border-3">
                            <thead>
                                <tr>
                                    <th class="text-theme">Teams</th>
                                    <th class="text-theme text-end">Balance Left</th>
                                    <th class="text-theme text-end">Players</th>
                                </tr>
                            </thead>
                            <tbody class="fw-bold text-white">
                                <?php foreach ($teams as $row) : ?>
                                    <tr>
                                        <td class="p-4 border-bottom border-3 border-light" style="background: linear-gradient(var(--color), #000)"><?= $row->name ?></td>
                                        <td class="text-end p-4 border-bottom border-3 border-light" style="background: linear-gradient(var(--color), #000)"><balance2><?= $playerX->sumTotal(['team_id' => $row->id], [], 'price') ?></balance2></td>
                                        <td class="text-end p-4 border-bottom border-3 border-light" style="background: linear-gradient(var(--color), #000)"><?= $playerX->total(['team_id' => $row->id]) ?></td>
                                    </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer d-none">
                        <button type="button" class="btn btn-black" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- /balance left -->


        <div class="container-fluid px-0 pt-3">

            <div class="row mx-0 text-start">

                <p class="auction_name auction_name_font text-center fw-bold fs-0">
                    <span class="text-warning px-3 bg-warning lh-base text-theme rounded"><?= strtoupper($player->name) ?><pricex class="d-none"></pricex></span>
                </p>
                <div class="auction_img col-6 offset-3 d-flex justify-content-center mb-3 position-relative">
                    <img src="<?= ROOT . '/public/assets/images/players/' . $player->image . '?v=' . $updated ?>" class="rounded-pill border border-warning border-3 oveflow-hidden shadow-lg w-50 bg-white cursor-zoom" onclick="bigImage(this)" />
                    <?php if ($player->status == 'sold') : ?>
                        <img class="auction_player_sold" src="<?= ROOT . '/public/assets/images/files/sold_yellow.png?v=' .  $updated ?>">
                    <?php endif ?>
                </div>

                <div class="col-12 text-center px-0">

                    <p class="auction_role auction_name_font fw-bold text-light fs-1 text-center d-flex justify-content-center align-items-center <?= $player->status == 'sold' ? 'd-none' : '' ?>">

                        <span class=" px-4 text-light lh-lg shadow-lg fs-3 me-1" style="background-image: linear-gradient(#19b904 12%,#125109 60%);"><?= strtoupper($player->role) ?></span>

                        <!-- Batsman-->
                        <?php if ($player->role == 'Batsman') : ?>
                            <span class="shadow-lg text-light  px-3 fs-3 lh-lg" style="background-image: linear-gradient(#0d6efd 12%,#0f2c57  60%);">
                                <img src="<?= ROOT . '/public/assets/images/files/bat.png?v=' . $updated ?>" class="auction_style mx-2">
                                <b><?= strtoupper($player->batting_style) ?> </b>
                            </span>

                            <!-- Bowler-->
                        <?php elseif ($player->role == 'Bowler') : ?>
                            <span class="shadow-lg text-light  px-3 fs-3 lh-lg" style="background-image: linear-gradient(#0d6efd 12%,#0f2c57  60%);">
                                <img src="<?= ROOT . '/public/assets/images/files/ball.png?v=' . $updated ?>" class="auction_style mx-2">
                                <b><?= strtoupper($player->bowling_style) ?> </b>
                            </span>

                            <!-- Wicket-Keeper-->
                        <?php elseif ($player->role == 'Wicket Keeper') : ?>
                            <span class="shadow-lg text-light  px-3 fs-3 lh-lg" style="background-image: linear-gradient(#0d6efd 12%,#0f2c57  60%);">
                                <img src="<?= ROOT . '/public/assets/images/files/bat.png?v=' . $updated ?>" class="auction_style mx-2">
                                <b><?= strtoupper($player->batting_style) ?> </b>
                            </span>

                            <!-- All Rounder-->
                        <?php elseif ($player->role == 'All Rounder') : ?>
                            <span class="shadow-lg text-light  px-3 fs-3 lh-lg" style="background-image: linear-gradient(#0d6efd 12%,#0f2c57  60%);">
                                <img src="<?= ROOT . '/public/assets/images/files/bat.png?v=' . $updated ?>" class="auction_style mx-2">
                                <b><?= strtoupper($player->batting_style) ?> </b>
                                <img src="<?= ROOT . '/public/assets/images/files/ball.png?v=' . $updated ?>" class="auction_style mx-2 border-start border-secondary">
                                <b><?= strtoupper($player->bowling_style) ?> </b>
                            </span>
                        <?php endif ?>

                        <!-- town -->
                        <?php if ($player->town != '') : ?>
                            <span class="ms-1 shadow-lg text-light ms-0 ps-4  pe-3 lh-lg fs-3" style="background-image: linear-gradient(#6c757d 12%,#2d3033 60%);">
                                <icon class="me-1"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-geo-alt-fill mb-1" viewBox="0 0 16 16">
                                        <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"></path>
                                    </svg></icon>
                                <b><?= strtoupper($player->town) ?></b>
                            </span>
                        <?php endif; ?>

                    </p>

                    <!-- sold text -->
                    <div class="row fw-bold sold_done mt-4 <?= $player->status == 'sold' ? '' : 'd-none' ?>">
                        <div class="col-12">
                            <div class="d-block pb-5 shadow-lg text-white px-1 lh-base" style="background-image: linear-gradient(transparent 0%,#214022 50%);font-size:3.5rem;">
                                <p class="mb-2 ps-0 lh-base">
                                    <span class=" text-white px-4">SOLD TO <b class="text-white"><?= strtoupper($team->name) ?></b></span>
                                </p>
                                <p class="mb-0 ps-0 lh-base">
                                    <span class="rounded-theme text-black px-5" style="background-image: linear-gradient(#fff 12%,#fff 60%);"><?= moneyFormatIndia($player->price) ?></span>
                                </p>
                                <br><br><br><br><br><br>
                            </div>
                        </div>
                    </div>

                    <!-- auction form -->
                    <form action="<?= ROOT . '/auction/sold/' . $player->id ?>" method="post" class="auction_form <?= $player->status == 'sold' ? 'invisible' : '' ?> auction_name_font pb-5 position-relative bg-sold">

                        <div class="auction_footer d-block px-2 pb-5 position-relative overflow-hidden">

                            <span class="changeBid fw-bold fw-bold text-light bg-warning fs-2 px-3 me-3 w-100">
                                <b class="transform-skew mt-3 bg-body px-5 shadow label-theme">BASE PRICE</b>
                            </span>
                            <span class="selectTeam d-none fw-bold fw-bold text-light bg-warning fs-2 px-3 me-3 w-100">
                                <b class="transform-skew mt-3 bg-body px-5 shadow text-black">
                                    <sold class="d-block label-theme">SELECT TEAM</sold>
                                </b>
                            </span>

                            <!-- input fields -->
                            <input type="text" name="price" class="input_price mt-5 text-light text-center pt-3" value="500" readonly>
                            <input type="hidden" class="input_team" name="team_id">
                            <button type="submit" name="submit" class="submit btn btn-primary d-none">Submit</button>

                            <div class="team_list row justify-content-around d-none text-light mt-5 text-uppercase">

                                <?php foreach ($teams as $row) : ?>
                                    <div class="team_select col-3 mb-3 border-bottom border-danger pb-3 fs-5" data-id="<?= $row->id ?>" data-name="<?= $row->name ?>" data-img="<?= ROOT . '/public/assets/images/teams/' . $row->logo . '?v=' . $updated ?>" data-color="<?= $row->theme ?>">
                                        <logo class="auction_team_logo mb-0">
                                            <img class="shadow-theme-2 bg-white rounded-pill" src="<?= ROOT . '/public/assets/images/teams/' . $row->logo . '?v=' . $updated ?>">
                                        </logo>
                                        <name class="fw-bold  fs-3"><?= $row->name ?></name>
                                        <balance class=" fs-4">
                                            <?= $playerX->sumTotal(['team_id' => $row->id], [], 'price') ?>
                                        </balance>
                                    </div>

                                <?php endforeach ?>
                            </div>

                            <!-- final sold page -->
                            <div class="team_final text-light fs-0 mt-4 d-none text-uppercase sold_text">

                                <p class="b-2 ps-0 mb-1 lh-base  text-warning fw-bold w-100 d-none"><?= strtoupper($player->name) ?></p>
                                
                                <b class="">SOLD TO</b> <span class="sold_team fw-bold  text-warning"></span> <b class="">FOR</b> <span class="sold_price  text-warning fw-bold"></span>
                                <div class="row my-5">
                                    <div class="col-6 border-end border-secondary position-relative">
                                        <img class="player_img rounded-pill border border-warning border-3 oveflow-hidden shadow-lg w-50" src="<?= ROOT . '/public/assets/images/players/' . $player->image . '?v=' . $updated ?>" />
                                        <img class="auction_player_sold" src="<?= ROOT . '/public/assets/images/files/sold_yellow.png?v=' .  $updated ?>">
                                    </div>
                                    <div class="col-6">
                                        <img class="sold_img rounded-pill border border-warning border-3 oveflow-hidden shadow-lg w-50" src="">
                                    </div>
                                </div>
                                <p class="text-center final_button"><button class="done btn btn-light py-3 px-5 fw-bold">Visit Team</button></p>
                            </div>
                        </div>
                    </form>
                    <form action="<?= ROOT . '/auction/unsold/' . $player->id ?>" method="post" class="d-none">
                        <input type="hidden" name="player_id_us" value="35">
                        <button type="submit" name="unsold_submit" class="unsold_submit btn btn-primary d-none">Submit</button>
                    </form>
                </div>
            </div>

            <span class="cus-bid cus-bid-increase w-auto <?= $player->status == 'sold' ? 'd-none' : '' ?>">
                <b>INCREASE</b>
                <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" fill="#fff" class="bi bi-plus-circle-fill" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0M8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3z" />
                </svg>
            </span>
            <span class="cus-bid cus-bid-decrease w-auto <?= $player->status == 'sold' ? 'd-none' : '' ?>">
                <b>DECREASE</b>
                <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" fill="#fff" class="bi bi-dash-circle-fill" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0M4.5 7.5a.5.5 0 0 0 0 1h7a.5.5 0 0 0 0-1z" />
                </svg>
            </span>
            <span class="cus-sold w-auto <?= $player->status == 'sold' ? 'd-none' : '' ?>">
                <b class="soldx">SOLD</b>
                <b class="backx d-none">BACK</b>
                <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" fill="currentColor" class="bi bi-person-plus cus-sold-add" viewBox="0 0 16 16">
                    <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
                    <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z" />
                </svg>
                <!-- <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" fill="currentColor" class="bi bi-arrow-left-circle-fill cus-back d-none text-black" viewBox="0 0 16 16">
                    <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z" />
                </svg> -->
                <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" fill="#fff" class="bi bi-x-circle-fill cus-back d-none bg-black rounded-pill" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0M5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293z" />
                </svg>
            </span>
            <span class="cus-unsold w-auto <?= $player->status == 'sold' ? 'd-none' : '' ?>">
                <b>UNSOLD</b>
                <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" fill="currentColor" class="bi bi-person-x" viewBox="0 0 16 16">
                    <path d="M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm.256 7a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z" />
                    <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm-.646-4.854.646.647.646-.647a.5.5 0 0 1 .708.708l-.647.646.647.646a.5.5 0 0 1-.708.708l-.646-.647-.646.647a.5.5 0 0 1-.708-.708l.647-.646-.647-.646a.5.5 0 0 1 .708-.708Z" />
                </svg></span>
        </div>
        <script>

            // big image
            function bigImage(e) {
                alert(`<img src="${e.src}" class="preview_player img-fluid h-100" />`);
            }

            // body - scrollbar hidden
            document.body.classList.add('overflow-hidden');

            // add class after full site load    
            window.onload = function() {
                setTimeout(() => document.querySelector('.auction_name').classList.add('auction_name_show'), 1000);
                setTimeout(() => document.querySelector('.auction_img').classList.add('auction_img_show'), 1200);
                setTimeout(() => {
                    document.querySelector('.auction_form').classList.add('form_up');
                    document.querySelector('.sold_done').classList.add('form_up');
                }, 1200);
                setTimeout(() => document.querySelector('.auction_role').classList.add('auction_role_show'), 1400);
            };

            // bids
            let bid = getBid();
            let bid_limit = bid.length - 1;
            let current_index = 0;

            // set initial price
            document.querySelector(".input_price").value = bid[0];
            document.querySelector("pricex").innerHTML = bid[0];

            // increase/dcrease Price
            document.querySelector('.cus-bid.cus-bid-increase').addEventListener('click', () => current_index != bid_limit && current_index++);
            document.querySelector('.cus-bid.cus-bid-decrease').addEventListener('click', () => current_index != 0 && current_index--);

            // calculate balance left
            document.querySelectorAll('balance').forEach(b => b.innerHTML = Number(getHighestBid()) - Number(b.innerHTML));
            document.querySelectorAll('balance2').forEach(b => b.innerHTML = Number(getHighestBid()) - Number(b.innerHTML));

            // bid effects
            document.querySelectorAll('.cus-bid').forEach(c => c.addEventListener('click', function() {
                document.querySelector(".changeBid b").innerText = "CURRENT BID";
                document.querySelector(".input_price").value = bid[current_index];
                document.querySelector("pricex").innerHTML = bid[current_index];
                document.querySelector(".input_price").classList.add("priceVBig");
                setTimeout(function() {
                    document.querySelector(".input_price").classList.remove("priceVBig");
                }, 300);
            }));

            // Sold button clicked
            document.querySelector('.cus-sold').addEventListener('click', () => {
                document.querySelector('.cus-sold .cus-back').classList.toggle("d-none");
                document.querySelector('.cus-sold .soldx').classList.toggle("d-none");
                document.querySelector('.cus-sold .backx').classList.toggle("d-none");
                document.querySelector('.cus-sold .cus-sold-add').classList.toggle("d-none");
                document.querySelector('.cus-unsold').classList.toggle("d-none");
                document.querySelector('.team_list').classList.toggle('d-none');
                document.querySelectorAll('.cus-bid').forEach(c => c.classList.toggle('d-none'));
                document.querySelector('.selectTeam').classList.toggle('d-none');
                document.querySelector('.changeBid').classList.toggle('d-none');
                document.querySelector('.input_price').classList.toggle('d-none');
                document.querySelector('.auction_role').classList.toggle('d-none');
                document.querySelector('pricex').classList.toggle('d-none');
                document.querySelector('.auction_body').classList.toggle('black-bg');
                document.querySelector('.auction_form').classList.toggle('select-team');
            });

            // Selected Team
            document.querySelectorAll('.team_select').forEach(s => {
                s.addEventListener('click', () => {
                    document.querySelector('.cus-sold').classList.toggle('d-none');
                    document.querySelector('.input_team').value = s.getAttribute('data-id');
                    document.querySelector('.team_list').classList.toggle('d-none');
                    document.querySelector('.selectTeam').classList.toggle('d-none');
                    document.querySelector('.team_final').classList.remove('d-none');
                    document.querySelector('.sold_team').innerText = s.getAttribute('data-name');
                    document.querySelector('.sold_price').innerText = document.querySelector('.input_price').value;
                    document.querySelector('.sold_img').src = s.getAttribute('data-img');
                    document.querySelector('.auction_footer').parentElement.style.backgroundImage = "linear-gradient(" + s.getAttribute('data-color') + ", black)";
                });

            });
            // Final Sold Click
            document.querySelector('.done').addEventListener('click', () => {
                document.querySelector('.submit').click();
            });
            // Unsold button clicked
            document.querySelector('.cus-unsold').addEventListener('click', () => {
                document.querySelector('.unsold_submit').click();
            });
        </script>
    </div>
    <script>
        setTimeout(function() {
            document.querySelector('.loader').classList.add('d-none');
            document.querySelector('.auction-wrapper').classList.remove('invisible');
        }, 800);
    </script>
    <!-- /wrapper -->


    <br><br><br><br><br>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script src="<?= ROOT ?>/public/assets/js/script.js?v=<?= $updated ?>"></script>

</body>

</html>