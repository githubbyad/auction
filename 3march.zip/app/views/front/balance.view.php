<?php
$this->view('front/inc/header', $data);
$playerZ = new \app\models\Player;
?>

<?php $this->view('response'); ?>

<div class="auction_div container-fluid px-lg-5 my-5">

    <!--Balance-->
    <div class="balance_row row mx-0 my-5 pb-5 bg-light rounded-theme shadow-theme px-3 px-lg-5 text-uppercase justify-content-center fw-bold">

        <h1 id="balance" class="fw-bold text-theme py-4 border-bottom border-theme border-3 mb-3 mt-2 text-center auction_name_font fst-italic">Balance Left</h1>
        <?php foreach ($teams as $row) : ?>

            <div class="col-lg-3 p-2 mx-0 mb-3 position-relative auction_name_font">

                <div class="balance_div w-100 border border-2 border-theme rounded-theme px-2 py-3 text-center" style="background-image: linear-gradient(<?= $row->theme ?> 20%,#000 86%);border-color:<?= $row->theme ?> !important;">

                    <p class="text-center">
                        <img src="<?= ROOT . '/public/assets/images/teams/' . $row->logo . '?v=' . $updated ?>" class="img-fluid w-50 shadow-theme-2 rounded-pill border border-2" style="border-color:<?= $row->theme ?> !important;" />
                    </p>

                    <p class="text-center text-white border-bottom border-1 border-secondary pb-2 fs-4 mb-2" style="border-color:<?= $row->theme ?> !important;"><?= strtoupper($row->name) ?></p>

                    <p class="text-center fs-6 text-light mt-3 mb-0">Balance Left</p>
                    <span class="text-center fs-2 bg-light px-5 text-red rounded mb-2">
                        <balanceZ><?= $playerZ->sumTotal(['team_id' => $row->id], [], 'price') ?></balanceZ>
                    </span>

                    <p class="text-center fs-6 text-light mt-3 mb-2 pt-2 border-top border-1 border-secondary" style="border-color:<?= $row->theme ?> !important">Total Players</p>
                    <span class="text-center fs-2 px-3 text-white mb-2"><?= $playerZ->total(['team_id' => $row->id]) ?></span>
                </div>
            </div>
        <?php endforeach ?>

        <?php if (!is_array($teams) && $teams == 0) : ?>
            <div class='alert alert-danger fw-bold'>There are no players added here.</div>
        <?php endif ?>

    </div><br><br><br><br><br>
    <!--/Balance-->

</div>

<script>
    document.querySelectorAll('balanceZ').forEach(b => b.innerHTML = Number(getHighestBid()) - Number(b.innerHTML));
</script>

<?php $this->view('front/inc/bookmark', $data); ?>

<?php $this->view('front/inc/footer', $data); ?>