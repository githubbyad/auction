<?php $this->view('front/inc/header', $data); ?>


<?php $this->view('response'); ?>

<style>
    body {
        background-image: linear-gradient(<?= $team->theme ?> 50%, #e7e7e7);
    }

    .auction_up_color {
        background-color: <?= $team->theme ?>;
    }

    .border-theme {
        border-color: #18184A !important;
    }

    .text-theme {
        color: #18184A !important;
    }
</style>
<div id="team" class="auction_div container-fluid px-lg-0 my-5 auction_name_font">
    <!-- team -->
    <div class="row mx-0 mt-5 mb-2 pb-3 bg-light border border-2 justify-content-center rounded-theme position-relative shadow-theme px-3" style="background-image: linear-gradient(<?= $team->theme ?> 20%,#000 86%);border-color:<?= $team->theme ?> !important">
        <p class="border-bottom border-secondary border-3 mb-3 mt-2 py-4 text-center" style="border-color:<?= $team->theme ?> !important">
            <img src="<?= ROOT . '/public/assets/images/teams/' . $team->logo . '?v=' . $updated ?>" class="team_image_main img-fluid bg-white shadow-theme-2 rounded-pill border border-2" style="max-height:300px;border-color:<?= $team->theme ?> !important">
            <span class="fw-bold text-light py-2 text-center text-uppercase w-100 fs-1 d-block"><?php echo $team_name; ?></span>
            <span class="text-light fw-bold px-2 py-1 rounded shadow-lg" style="background-color:<?= $team->theme ?> !important;">Total Players : <?= $player_total ?></span>
        </p>

        <?php foreach ($players as $player) :
            $role = BAT;
            $player->role == 'Batsman' && $role = BAT;
            $player->role == 'Bowler' && $role = BALL;
            $player->role == 'All Rounder' && $role = ALL;
            $player->role == 'Wicket Keeper' && $role = KEEPER;
        ?>
            <div class="col-4 col-lg-2 p-1 p-lg-1 mx-0 mb-1 mb-lg-3 position-relative auction_name_font">

                <div class="row rounded-pill text-white align-items-center">

                    <div class="col-12 team_round position-relative d-flex justify-content-center align-items-center">

                        <?php if (admin()) : ?>
                            <a href="<?= ROOT ?>/auction?id=<?= $player->id ?>">
                            <?php endif ?>

                            <img src="<?= ROOT . '/public/assets/images/players/' . $player->image . '?v=' . $updated ?>" class="img-fluid rounded-pill border border-light border-2 shadow-sm" style="border-color:<?= $team->theme ?> !important" />

                            <?php if (admin()) : ?></a><?php endif ?>

                        <span class="team_sold_icons" style="background-color:<?= $team->theme ?> !important;">
                            <img src="<?= $role ?>" class="img-fluid me-1" style="max-width: 22px;" />
                        </span>

                        <span class="team_sold_price fw-bold fs-7 fs-lg-4 text-light px-2 px-lg-5 d-block" style="background-color:<?= $team->theme ?> !important;"><?= moneyFormatIndia($player->price) ?></span>
                    </div>

                    <div class="col-12 text-center text-secondary text-uppercase">
                        <span class="fs-7 fs-lg-5 fw-bold my-0 text-light text-center w-100 lh-sm d-block"><?= get_firstname($player->name) ?></span>
                        <span class="fs-8 fs-lg-7 fw-bold my-0 text-center w-100 lh-sm d-block"><?= get_lastname($player->name) ?></span>
                    </div>
                </div>
            </div>
        <?php endforeach ?>

        <?php if ($player_total == 0) : ?>
            <div class='alert alert-danger fw-bold'>There are no players added here.</div>
        <?php endif ?>

        <p class="py-3 mt-5 border-top border-2 mb-0" style="border-color:<?= $team->theme ?> !important"></p>

        <div class="col-12 text-center pb-2">
            <span class="team_owner_bottom text-uppercase d-inline-block text-center position-relative bottom-0 w-auto text-light lh-lg px-2 fs-7x5 fs-6 bg-dark rounded fw-bold" style="background-color:<?= $team->theme ?> !important;">Team Owner
                <b style="fill:white">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-short mb-1" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z" />
                    </svg>
                </b> <?= $team->owner ?></span>
        </div>
    </div><br><br><br><br><br>
    <!-- /team -->


    <!-- balance left -->
    <span class="bal_left text-center py-2 auction_name_font">
        <b class="me-2">Balance Left</b>
        <price><?= $balance ?></price>
    </span>
    <!-- /balance left -->

</div>

<?php $this->view('front/inc/bookmark', $data); ?>

<?php $this->view('front/inc/footer', $data); ?>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        