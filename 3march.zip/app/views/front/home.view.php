<?php $this->view('front/inc/header', $data); ?>

<div class="auction_div container-fluid px-lg-5 mb-5">

    <?php $this->view('response'); ?>
    
    <!--Batsman-->
    <div class="row mx-0 my-5 pb-3 bg-light rounded-theme shadow-theme px-3 px-lg-5">

        <h1 id="batsman" class="fw-bold text-theme py-4 border-bottom border-theme border-3 mb-5 mt-2 text-center auction_name_font fst-italic">BATSMAN</h1>

        <?php foreach ($batsman as $row) : ?>

            <div class="col-4 col-lg-2 p-2 mx-0 mb-4 pb-3 border-bottom position-relative auction_name_font">

                <div class="row rounded-pill text-white align-items-center" data-status="<?= $row->status == 'sold' ? 'sold' : '' ?>">

                    <div class="col-12 position-relative d-flex justify-content-center align-items-center position-relative">

                        <?php if (admin()) : ?> <a href="<?= ROOT ?>/auction?id=<?= $row->id ?>"> <?php endif ?>

                            <img src="<?= ROOT . '/public/assets/images/players/' . $row->image . '?v=' . $updated ?>" class="img-fluid player_img rounded-pill border border-warning border-2 shadow-theme" />

                            <?php if (admin()) : ?></a><?php endif ?>

                        <?php if ($row->status == 'sold') : ?><img class='player_sold' src="<?= SOLD_YELLOW ?>">
                        <?php elseif ($row->status == 'not sold') : ?><img class='player_notsold' src="<?= UNDSOLD_RED ?>"><?php endif ?>

                    </div>

                    <div class="col-12 mt-2 mt-lg-3 text-center text-secondary text-uppercase">

                        <span class="fs-7 fs-lg-5 fw-bold my-0 text-dark text-center w-100 lh-sm d-block"><?= get_firstname($row->name) ?></span>

                        <span class="fs-8 fs-lg-7 fw-bold my-0 text-center w-100 lh-sm d-block"><?= get_lastname($row->name) ?></span>

                    </div>
                </div>
            </div>
        <?php endforeach ?>
    </div><br><br><br><br><br>
    <!--/Batsman-->


    <!--Bowler-->
    <div class="row mx-0 my-5 pb-3 bg-light rounded-theme shadow-theme px-3 px-lg-5">

        <h1 id="bowler" class="fw-bold text-theme py-4 border-bottom border-theme border-3 mb-5 mt-2 text-center auction_name_font fst-italic">BOWLER</h1>

        <?php foreach ($bowler as $row) : ?>

            <div class="col-4 col-lg-2 p-2 mx-0 mb-4 border-bottom position-relative auction_name_font">

                <div class="row rounded-pill text-white align-items-center" data-status="<?= $row->status == 'sold' ? 'sold' : '' ?>">

                    <div class="col-12 position-relative d-flex justify-content-center align-items-center position-relative">

                        <?php if (admin()) : ?> <a href="<?= ROOT ?>/auction?id=<?= $row->id ?>"> <?php endif ?>

                            <img src="<?= ROOT . '/public/assets/images/players/' . $row->image . '?v=' . $updated ?>" class="img-fluid player_img rounded-pill border border-warning border-2 shadow-theme" />

                            <?php if (admin()) : ?></a><?php endif ?>

                        <?php if ($row->status == 'sold') : ?><img class='player_sold' src="<?= SOLD_YELLOW ?>">
                        <?php elseif ($row->status == 'not sold') : ?><img class='player_notsold' src="<?= UNDSOLD_RED ?>"><?php endif ?>

                    </div>

                    <div class="col-12 mt-2 mt-lg-3 text-center text-secondary text-uppercase">

                        <span class="fs-7 fs-lg-5 fw-bold my-0 text-dark text-center w-100 lh-sm d-block"><?= get_firstname($row->name) ?></span>

                        <span class="fs-8 fs-lg-7 fw-bold my-0 text-center w-100 lh-sm d-block"><?= get_lastname($row->name) ?></span>

                    </div>
                </div>
            </div>
        <?php endforeach ?>
    </div><br><br><br><br><br>
    <!--/Bowler-->

    <!--All Rounder-->
    <div class="row mx-0 my-5 pb-3 bg-light rounded-theme shadow-theme px-3 px-lg-5">

        <h1 id="all" class="fw-bold text-theme py-4 border-bottom border-theme border-3 mb-5 mt-2 text-center auction_name_font fst-italic">ALL ROUNDER</h1>

        <?php foreach ($all_rounder as $row) : ?>

            <div class="col-4 col-lg-2 p-2 mx-0 mb-4 pb-3 border-bottom position-relative auction_name_font">

                <div class="row rounded-pill text-white align-items-center" data-status="<?= $row->status == 'sold' ? 'sold' : '' ?>">

                    <div class="col-12 position-relative d-flex justify-content-center align-items-center position-relative">

                        <?php if (admin()) : ?> <a href="<?= ROOT ?>/auction?id=<?= $row->id ?>"> <?php endif ?>

                            <img src="<?= ROOT . '/public/assets/images/players/' . $row->image . '?v=' . $updated ?>" class="img-fluid player_img rounded-pill border border-warning border-2 shadow-theme" />

                            <?php if (admin()) : ?></a><?php endif ?>

                        <?php if ($row->status == 'sold') : ?><img class='player_sold' src="<?= SOLD_YELLOW ?>">
                        <?php elseif ($row->status == 'not sold') : ?><img class='player_notsold' src="<?= UNDSOLD_RED ?>"><?php endif ?>

                    </div>

                    <div class="col-12 mt-2 mt-lg-3 text-center text-secondary text-uppercase player_name">

                        <span class="fs-7 fs-lg-5 fw-bold my-0 text-dark text-center w-100 lh-sm d-block"><?= get_firstname($row->name) ?></span>

                        <span class="fs-8 fs-lg-7 fw-bold my-0 text-center w-100 lh-sm d-block"><?= get_lastname($row->name) ?></span>

                    </div>
                </div>
            </div>
        <?php endforeach ?>
    </div><br><br><br><br><br>

    <!--/All Rounder-->

    <!--Wicket Keeper-->
    <div class="row mx-0 my-5 pb-3 bg-light rounded-theme shadow-theme px-3 px-lg-5">

        <h1 id="keeper" class="fw-bold text-theme py-4 border-bottom border-theme border-3 mb-5 mt-2 text-center auction_name_font fst-italic">WICKET KEEPER</h1>

        <?php foreach ($keeper as $row) : ?>

            <div class="col-4 col-lg-2 p-2 mx-0 mb-4 pb-3 border-bottom position-relative auction_name_font">

                <div class="row rounded-pill text-white align-items-center" data-status="<?= $row->status == 'sold' ? 'sold' : '' ?>">

                    <div class="col-12 position-relative d-flex justify-content-center align-items-center position-relative">

                        <?php if (admin()) : ?> <a href="<?= ROOT ?>/auction?id=<?= $row->id ?>"> <?php endif ?>

                            <img src="<?= ROOT . '/public/assets/images/players/' . $row->image . '?v=' . $updated ?>" class="img-fluid player_img rounded-pill border border-warning border-2 shadow-theme" />

                            <?php if (admin()) : ?></a><?php endif ?>

                        <?php if ($row->status == 'sold') : ?><img class='player_sold' src="<?= SOLD_YELLOW ?>">
                        <?php elseif ($row->status == 'not sold') : ?><img class='player_notsold' src="<?= UNDSOLD_RED ?>"><?php endif ?>

                    </div>

                    <div class="col-12 mt-2 mt-lg-3 text-center text-secondary text-uppercase">

                        <span class="fs-7 fs-lg-5 fw-bold my-0 text-dark text-center w-100 lh-sm d-block"><?= get_firstname($row->name) ?></span>

                        <span class="fs-8 fs-lg-7 fw-bold my-0 text-center w-100 lh-sm d-block"><?= get_lastname($row->name) ?></span>

                    </div>
                </div>
            </div>
        <?php endforeach ?>
    </div><br><br><br><br><br>
    <!--/Wicket Keeper-->

</div>

<?php $this->view('front/inc/bookmark', $data); ?>

<?php $this->view('front/inc/footer', $data); ?>