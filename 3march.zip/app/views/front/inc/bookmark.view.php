<?php
$playerX = new \app\models\Player;

if (isset($_SESSION[APP]['role']) && $_SESSION[APP]['role'] > 0) { ?>

    <div class="bookmark position-fixed start-0 bg-dark text-light bottom-0 w-100 pb-2 pt-4 rounded-theme px-5" style="border-bottom-right-radius: 0 !important;border-bottom-left-radius: 0 !important;">
        <span class="bb">
            <b>Batsman</b>
            <a href="<?= ROOT ?>/#batsman"><img src="<?= BAT ?>" class="img-role2 img-fluid" /></a>
        </span>
        <span class="bb">
            <b>Bowler</b>
            <a href="<?= ROOT ?>/#bowler" title="Bowler"><img src="<?= BALL ?>" class="img-role2 img-fluid" /></a>
        </span>
        <span class="bb">
            <b>All Rounder</b>
            <a href="<?= ROOT ?>/#all" title="All Rounder"><img src="<?= ALL ?>" class="img-role2 img-fluid" /></a>
        </span>
        <span class="bb">
            <b>Weeket Keeper</b>
            <a href="<?= ROOT ?>/#keeper" title="Weeket Keeper"><img src="<?= KEEPER ?>" class="img-role2 img-fluid" /></a>
        </span>

        <?= DOT . DOT . DOT ?>        

        <span class="shuffle_new bb">
            <b>New Player</b>
            <a href="<?= ROOT ?>/auction" class="d-inline text-decoration-none rounded-pill text-warning">
                <?= ICON_PLAYER ?>
                <span><?= $fresh_player ?></span>
            </a>
        </span>

        <?= DOT . DOT . DOT?>        


        <span class="shuffle_unsold bb">
            <b>Unsold Players</b>
            <a href="<?= ROOT ?>/auction/unsoldShow" class="d-inline text-decoration-none rounded-pill text-red">
                <?= ICON_UNSOLD ?>
                <span><?= $notsold_player ?></span>
            </a>
        </span>

        <?= DOT . DOT . DOT . DOT . DOT . DOT ?>

        <span class="bb d-none">
            <b>Write Player ID</b>
            <form action="<?= ROOT ?>/auction" method="get" class="d-inline">
                <input type="text" onkeypress="return isNumberKey(this, event);" name="id" class="form_aution lh-lg" required autocomplete="off">
                <button type="submit" class="btn btn-primary d-none">Submit</button>
            </form>
        </span>

        <?= DOT . DOT ?>

        <span class="bb shuffle_new book_expensive">
            <b>Most Expensive Players</b>
            <a href="<?= ROOT ?>/expensive#expensive" class="d-inline text-decoration-none rounded-pill text-info"><?= ICON_CURRENT ?></a>
        </span>
        <span class="bb shuffle_new book_balance">
            <b>Balance Left</b>
            <a href="<?= ROOT ?>/balance#balance" class="d-inline text-decoration-none rounded-pill"><?= ICON_BALANCE ?></a>
        </span>
        <span class="bb shuffle_new book_status">
            <b>Auction Status</b>
            <a href="<?= ROOT ?>/status#status" class="d-inline text-decoration-none rounded-pill"><?= ICON_WAIT ?></a>
        </span>
        <?= DOT ?>
        <?= DOT ?>
        <?= DOT ?>
        <span class="book_team ms-3 position-relative d-inline-block fw-bold" style="width:300px;">
            <?= ICON_PEOPLE ?>
            <teams class="book_team_active mb-3 bg-light p-2 rounded shadow-theme">
                <?php foreach ($teams as $row) : ?>
                    <a href="<?= ROOT ?>/team/<?= $row->id ?>#team" class="d-block bg-dark my-1 px-2 text-decoration-none w-100 text-light text-uppercase auction_name_font rounded fs-5 p-2" style="background: linear-gradient(var(--color), #000)">
                        <b class="text-warning"><?= $row->name ?></b> (<balanceX><?= $playerX->sumTotal(['team_id' => $row->id], [], 'price') ?></balanceX>)
                    </a>
                <?php endforeach ?>
            </teams>
        </span>
    </div>
<?php } ?>

<script>
    document.querySelectorAll('balanceX').forEach(b => b.innerHTML = Number(getHighestBid()) - Number(b.innerHTML));
</script>