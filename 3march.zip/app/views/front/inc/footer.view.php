<script src="<?= ASSETS ?>/js/front.js?v=" <?= $updated ?>></script>
<script src="<?= ASSETS ?>/js/script.js?v=" <?= $updated ?>></script>
</body>

</html>