<!doctype html>
<html lang="en">

<head>

    <title><?= $title ?></title>
    <link rel="shortcut icon" href="<?= ROOT . '/public/assets/images/' . $setting->favicon . '?v=' . $updated ?>" type="image/x-icon">

    <!-- meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="og:type" content="website">
    <meta name="twitter:title" content="<?= $title ?>">
    <meta name="og:title" content="<?= $setting->title ?>">
    <meta name="og:description" content="It's Auction Time! Get all information about the auction as it happened. Details about Highest Bid for players, most expensive players, players retained, Teams &amp; their formations!">
    <meta name="keywords" content="auction, cricket auction, cricket ground, limited over cricket" />
    <meta name="description" content="It's Auction Time! Get all information about the auction as it happened. Details about Highest Bid for players, most expensive players, Teams &amp; their formations!" />
    <meta name="og:image" content="<?= ROOT . '/public/assets/images/' . $setting->sharing_image . '?v=' . $updated ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />

    <!--bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <!--custom css-->
    <link rel="stylesheet" type="text/css" href="<?= ASSETS ?>/css/style.css?v=<?= $updated ?>">

    <!--custom js--->
    <script src="<?= ASSETS ?>/js/functions.js?v=<?= $updated ?>"></script>
</head>

<body class="auction_body px-0">

    <div class="container-fluid header_auction py-2" style="min-height:100%">

        <div class="row">
            <div class="auction_logo col-10 col-lg-8 offset-lg-2 text-lg-center">
                <span>
                    <a class="text-decoration-none text-light fw-bold fs-1 auction_name_font text-uppercase" href="<?= ROOT ?>"><img src="<?= ASSETS . '/images/' . $setting->logo . '?v=' . $updated ?>" class="img-fluid tournament_logo"></a>
                </span>
            </div>
            <div class="col-2 d-flex justify-content-center align-items-center">
                <span class="auction_menu visible">
                    <span class="ac_bar"><?= ICON_LIST ?></span>
                    <span class="ac_close d-none"><?= ICON_CLOSE ?></span>
                </span>
            </div>
        </div>
    </div>

    <div class="auction_menu_list container-fluid bg-white py-4 position-fixed">

        <ul class="ps-0 list-inline">

            <li class="auction_menu_li border-bottom border-0 pb-1 mb-1 <?= $menu == 'Home' ? 'menu_active' : '' ?>">
                <a class="auction_menu_ul link w-100 d-block py-2" href="<?= ROOT ?>"><?= ICON_HOME ?>Home</a>
            </li>

            <?php if (admin()) : ?>
                <li class="auction_menu_li border-bottom border-0 pb-1 mb-1 <?= $menu == 'Registration' ? 'menu_active' : '' ?>">
                    <a class="auction_menu_ul link w-100 d-block py-2" href="<?= ROOT . '/registration#registration' ?>"><?= ICON_REGISTRATION ?>Player Registration</a>
                </li>
            <?php endif ?>

            <li class="auction_menu_li border-bottom border-0 pb-1 mb-1 <?= $menu == 'Teams' ? 'menu_active' : '' ?>">
                <a class="auction_menu_ul w-100 d-block position-relative py-2" href="javascript:void(0);">
                    <?= ICON_TEAM ?>Teams<?= ICON_DOWN_ARROW ?>
                </a>
                <ul class="auction_submenu_li list-inline d-none">
                    <?php foreach ($teams as $row) : ?>
                        <li class="my-2 ms-3">
                            <a class="link py-2 w-100 d-block border-bottom border-0 py-2 ps-3" href="<?= ROOT ?>/team/<?= $row->id ?>/#team">
                                <?= ICON_RIGHT_ARROW ?><?= $row->name ?></a>
                        </li>
                    <?php endforeach ?>
                </ul>
            </li>

            <li class="auction_menu_li border-bottom border-0 pb-1 mb-1">
                <a class="auction_menu_ul w-100 d-block position-relative py-2" href="javascript:void(0);"><?= ICON_PERSON ?>Categories<?= ICON_DOWN_ARROW ?></a>
                <ul class="auction_submenu_li list-inline d-none">
                    <li class="my-2 ms-3">
                        <a class="link py-2 w-100 d-block border-bottom border-0 py-2 ps-3" href="<?= ROOT ?>/#batsman"><?= ICON_RIGHT_ARROW ?>Batsman</a>
                    </li>
                    <li class="my-2 ms-3">
                        <a class="link py-2 w-100 d-block border-bottom border-0 py-2 ps-3" href="<?= ROOT ?>/#bowler"><?= ICON_RIGHT_ARROW ?>Bowler</a>
                    </li>
                    <li class="my-2 ms-3">
                        <a class="link py-2 w-100 d-block border-bottom border-0 py-2 ps-3" href="<?= ROOT ?>/#all"><?= ICON_RIGHT_ARROW ?>All Rounder</a>
                    </li>
                    <li class="my-2 ms-3">
                        <a class="link py-2 w-100 d-block py-2 ps-3" href="<?= ROOT ?>/#keeper"><?= ICON_RIGHT_ARROW ?>Wicket Keeper</a>
                    </li>
                </ul>
            </li>

            <li class="auction_menu_li border-bottom border-0 pb-1 mb-1 <?= $menu == 'Expensive' ? 'menu_active' : '' ?>">
                <a class="auction_menu_ul link w-100 d-block py-2" href="<?= ROOT . '/expensive#expensive' ?>"><?= ICON_CHARGE ?>Most Expensive Players</a>
            </li>

            <li class="auction_menu_li border-bottom border-0 pb-1 mb-1 <?= $menu == 'Balance' ? 'menu_active' : '' ?>">
                <a class="auction_menu_ul link w-100 d-block py-2" href="<?= ROOT . '/balance#balance' ?>"><?= ICON_CURRENCY ?>Balance Left</a>
            </li>

            <li class="auction_menu_li border-bottom border-0 pb-1 mb-1 <?= $menu == 'Status' ? 'menu_active' : '' ?>">
                <a class="auction_menu_ul link w-100 d-block py-2" href="<?= ROOT . '/status#status' ?>"><?= ICON_STATUS ?>Auction Status</a>
            </li>

        </ul>
    </div>