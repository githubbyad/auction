<?php
$this->view('front/inc/header', $data);
$this->view('front/inc/authenticate', $data);

show($_SESSION['message']);
?>

<div class="auction_div container-fluid my-5">

    <div class="row mx-0">

        <div class="col-lg-6 offset-lg-3 position-relative">

            <div class="w-100 d-block bg-body rounded-theme shadow-theme">

                <p class="text-center text-theme fw-bold mb-0 pt-4 fs-3">Login</p>

                <form action="<?= ROOT . '/login/verify' ?>" method="post" class="p-2 p-lg-4">

                    <?php $this->view('response'); ?>

                    <div class="mb-4 mt-2 form-floating">
                        <input type="text" name="username" class="form-control" placeholder="Username" required>
                        <label class="form-label text-muted"><?= ICON_USER ?> Username</label>
                    </div>

                    <div class="mb-4 mt-2 form-floating">
                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                        <label class="form-label text-muted"><?= ICON_LOCK ?> Password</label>
                    </div>

                    <?php echo isset($exist_message) ? $exist_message : ""; ?>

                    <center>
                        <button type="submit" name="submit" class="btn btn-success border-0 bg-theme fw-bold w-50 my-4 py-3 rounded-pill">Login</button>
                    </center>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $this->view('front/inc/footer', $data); ?>