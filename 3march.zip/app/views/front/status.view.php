<?php $this->view('front/inc/header', $data); ?>

<div class="auction_div container-fluid px-lg-5 mb-5">

    <?php $this->view('response'); ?>

    <div class="auction_div container-fluid px-lg-5 my-5">

        <!--Status-->
        <div id="status" class="balance_row row mx-0 my-5 pb-5 bg-light rounded-theme shadow-theme px-3 px-lg-5 text-uppercase justify-content-center fw-bold">

            <h1 id="balance" class="fw-bold text-theme py-4 border-bottom border-theme border-3 mb-3 mt-2 text-center auction_name_font fst-italic">Auction PLAYER Status</h1>

            <div class="col-12 d-flex align-items-center justify-content-center fs-1 fw-bold">
                <span class="px-3 px-lg-5 bg-warning text-black py-3" style="background-image: linear-gradient(transparent,rgba(0,0,0,0.2));">TOTAL PLAYERS</span>
                <span class="px-3 px-lg-5 bg-black text-white py-3"><?= $total_players ?></span>
            </div>

            <div class="col-12 mt-4 d-flex align-items-center justify-content-center fs-1 fw-bold">
                <span class="px-3 px-lg-5 bg-success text-white py-3 me-0" style="background-image: linear-gradient(transparent,rgba(0,0,0,0.2));">SOLD PLAYERS</span>
                <span class="px-3 px-lg-5 bg-black text-white py-3"><?= $sold_player ?></span>
            </div>

            <div class="col-12 mt-4 d-flex align-items-center justify-content-center fs-1 fw-bold">
                <span class="px-3 px-lg-5 bg-danger text-white py-3 me-0" style="background-image: linear-gradient(transparent,rgba(0,0,0,0.2));">UNSOLD PLAYERS</span>
                <span class="px-3 px-lg-5 bg-black text-white py-3"><?= $notsold_player ?></span>
            </div>

            <div class="col-12 mt-4 d-flex align-items-center justify-content-center fs-1 fw-bold d-none">
                <span class="px-3 px-lg-5 bg-danger text-white py-3 me-0" style="background-image: linear-gradient(transparent,rgba(0,0,0,0.2));">PLAYERS LEFT</span>
                <span class="px-3 px-lg-5 bg-black text-white py-3"><?= $left_player ?></span>
            </div>



        </div><br><br><br><br><br>
        <!--/Status-->

    </div>

</div>

<?php $this->view('front/inc/bookmark', $data); ?>

<?php $this->view('front/inc/footer', $data); ?>