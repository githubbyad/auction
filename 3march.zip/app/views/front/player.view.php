<?php $this->view('front/inc/header', $data); ?>

<div class="auction_div container-fluid my-5">

    <div class="row mx-0">

        <div class="col-12">

            <div class="d-flex col-lg-6 offset-lg-3 justify-content-center align-items-center flex-column shadow-theme bg-body rounded p-4">

                <p class="text-dark text-start w-100 border-bottom pb-2 fw-bold">Player Details</p>

                <p>
                    <img src="<?= ROOT . '/public/assets/images/players/' . $player->image . '?v=' . $updated ?>" class="img-fluid player_img rounded-pill border border-warning border-2 shadow-sm" style="max-height: 200px;" />
                </p>

                <p class="fw-bold fs-5 text-theme"><?= ucwords($player->name) ?></p>

                <div class="table-responsive fixed-table-body">
                    <table class="table table-fit">
                        <tbody>

                            <tr>
                                <th scope="row" class="text-end">Role: </th>
                                <td class="text-start"><?= $player->role ?></td>
                            </tr>

                            <tr>
                                <th scope="row" class="text-end">Batting style: </th>
                                <td class="text-start"><?= $player->batting_style ?></td>
                            </tr>

                            <?php if ($player->role == 'Bowler' || $player->role == 'All Rounder') : ?>
                                <tr>
                                    <th scope="row" class="text-end">Bowling style: </th>
                                    <td class="text-start"><?= $player->bowling_style ?></td>
                                </tr>
                            <?php endif ?>

                            <?php if ($player->town != '') : ?>
                            <tr>
                                <th scope="row" class="text-end">Hometown: </th>
                                <td class="text-start"><?= $player->town ?></td>
                            </tr>
                            <?php endif ?>

                            <tr>
                                <th scope="row" class="text-end">Phone: </th>
                                <td class="text-start"><?= $player->phone ?></td>
                            </tr>

                            <tr>
                                <th scope="row" class="text-end">T-shirt size: </th>
                                <td class="text-start"><?= $player->tshirt_size ?></td>
                            </tr>

                            <?php if ($player->tshirt_number != '') : ?>
                                <tr>
                                    <th scope="row" class="text-end">T-shirt number: </th>
                                    <td class="text-start"><?= $player->tshirt_number ?></td>
                                </tr>
                            <?php endif ?>

                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

    <?php $this->view('front/inc/footer', $data); ?>