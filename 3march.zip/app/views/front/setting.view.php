<?php $this->view('inc/header', $data); ?>

<div class="col-12 px-0 py-2 p-2">

    <div class="w-100 bg-body py-2 px-3 mb-3 rounded shadow-sm">

        <p class="text-pink fw-normal mb-0 py-3">Setting</p>

        <form method="post" action="<?= ROOT ?>/setting/post" enctype="multipart/form-data">

            <input type="hidden" name="id" class="form-control" value="<?= $setting->id ?>" placeholder="">
            <div class="form-floating mb-3">
                <input type="text" name="logo_text" class="form-control" value="<?= $setting->logo_text ?>" placeholder="">
                <label class="form-label text-muted">Company Name</label>
            </div>
            <div class="form-floasting mb-3">
                <label class="form-label text-dark d-none">Upload Logo Image</label>
                <input type="file" name="logo_img" class="form-control" placeholder="">
                <img class="img-fluid mt-2 rounded shadow-sm" src="<?= ROOT . '/public/assets/images/logo.jpg?v=' . $setting->timestamp ?>" alt="logo image">
            </div>
            <div class="form-floating mb-3">
                <input type="text" name="currency" class="form-control" value="<?= $setting->currency ?>" placeholder="">
                <label class="form-label text-muted">Currency Symbol</label>
            </div>
            <div class="form-floating mb-3">
                <select class="form-select" name="theme" id="themeSelect" aria-label="Choose Theme" required>
                    <option value="light">Light</option>
                    <option value="dark">Dark</option>
                </select>
                <label for="themeSelect">Theme</label>
            </div>
            <div class="form-floating mb-3">
                <select class="form-select" name="fullscreen" id="full" aria-label="Choose Status" required>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
                <label for="full">Fullscreen</label>
            </div>

            <div class="text-center d-block my-4">
                <button type="submit" class="btn btn-dark fw-normal px-5 py-2">Submit</button>
            </div>

        </form>

    </div>
</div>

<script>
    document.querySelector("select[name='theme']").value = "<?= $setting->theme ?>";
    document.querySelector("select[name='fullscreen']").value = "<?= $setting->fullscreen ?>";
</script>

<?php $this->view('inc/footer', $data); ?>                                                