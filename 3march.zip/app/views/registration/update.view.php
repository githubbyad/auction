<?php $this->view('front/inc/header', $data); ?>

<div class="auction_div container-fluid px-lg-5 mb-5">

    <?php $this->view('response'); ?>

    <!--Registration-->
    <div id="registration" class="balance_row row mx-0 my-5 pb-5 bg-light rounded shadow px-3 justify-content-center fw-bold">

        <h3 id="balance" class="fw-bold text-theme py-4 border-bottom border-theme border-3 mb-3 mt-2 text-center auction_name_font"><?= strtoupper($setting->title) ?></h3>

        <!--tournament notes-->
        <div class="col-12 px-0 bg-gray text-black border border-gray rounded">
            <table class="reg_table table table-striped mb-0">
                <tr>
                    <td class="text-dark">Tournament Date</td>
                    <td> {{Date}}</td>
                </tr>
                <tr>
                    <td>Registration Fees</td>
                    <td>{{FEES}} currency symbol</td>
                </tr>
                <tr>
                    <td>Last Date of Submission</td>
                    <td>{{last date}}</td>
                </tr>
                <tr>
                    <td>Auction Date</td>
                    <td>{{auction date}}</td>
                </tr>
                <tr>
                    <td>Contact</td>
                    <td>Imran kalwada (+91 8758254040) Asfak Kazi (+91 8980786000) , Izharbhai Kazi (+91 9712786786) ,Mubarak Shaikh (+91 7359566616)</td>
                </tr>
                <tr>
                    <td>NOTE</td>
                    <td>{{note}}</td>
                </tr>
            </table>
        </div>
    </div>

    <div class="row my-5 pb-5 mx-0 bg-light rounded shadow px-3 justify-content-center fw-bold">
        <h3 id="balance" class="fw-bold text-theme py-4 border-bottom border-theme border-3 mb-3 mt-2 text-center auction_name_font">PLAYER REGISTRATION</h3>

        <!--form-->
        <form id="form" action="<?= ROOT ?>/registration/new" novalidate method="post" enctype="multipart/form-data" autocomplete="off" class="fw-normal py-3 px-0" onsubmit="return validate();">

            <div class="form-floating mb-4 w-100">
                <input type="text" name="name" id="name" value="<?= $form_data->name ?>" class="form-control" placeholder="Full Name">
                <label class="form-label text-muted">Full Name</label>
                <small class="text-danger d-none">* Please enter at least 3 letters</small>
            </div>

            <div class="mb-4 form-floating">
                <select class="form-select" name="role" id="role">
                    <option value="" selected disabled>Select Role</option>
                    <option value="Batsman">Batsman</option>
                    <option value="Bowler">Bowler</option>
                    <option value="All Rounder">All Rounder</option>
                    <option value="Wicket Keeper">Wicket Keeper</option>
                </select>
                <label for="role" class="form-label text-muted">Role</label>
                <small class="text-danger d-none">* Please select Player's Role</small>
            </div>

            <div class="mb-4 d-none form-floating">
                <select class="form-select" name="batting_style" id="batting_style">
                    <option value="" selected disabled>Select Batting Style</option>
                    <option value="Right">Right</option>
                    <option value="Left">Left</option>
                </select>
                <label class="form-label text-muted">Batting Style</label>
                <small class="text-danger d-none">* Please Batting Style</small>
            </div>
            <div class="mb-4 d-none form-floating">
                <select class="form-select" name="bowling_style" id="bowling_style">
                    <option value="" disabled>Select Bowling Style</option>
                    <option value="Right">Right</option>
                    <option value="Left">Left</option>
                </select>
                <label class="form-label text-muted">Bowling Style</label>
                <small class="text-danger d-none">* Please select Bowling Style</small>
            </div>

            <div class="mb-4 form-floating w-100">
                <input class="form-control" type="file" name="image" id="image" accept="image/png, image/jpeg">
                <label class="form-label text-muted mb-2">Upload Photo (Square)</label>
                <p class="text-muted ps-2 mb-0 mt-1"><?= ICON_HELP ?> Photo must be square. <sample class="cursor-pointer text-theme text-underline">See sample photo</sample>
                </p>
                <small class="text-danger d-none">* Please upload your photo.</small>
            </div>

            <div class="mb-4 mt-2 form-floating">
                <input type="text" name="phone" id="phone" onkeypress="return isPhoneNumber(this, event);" maxlength="10" class="form-control" placeholder="Phone">
                <label class="form-label text-muted">Phone</label>
                <small class="text-danger d-none">* Please enter 10 digits phone number.</small>
            </div>

            <div class="mb-4 mt-2 form-floating">
                <input type="text" name="town" id="town" class="form-control inputs" placeholder="Hometown" maxlength="15">
                <label class="form-label text-muted">Hometown</label>
                <small class="text-danger d-none">* Please enter your address</small>
            </div>

            <div class="mb-4 mt-2 form-floating">
                <input type="text" name="tshirt" id="tshirt" list="sizes" class="form-control inputs" placeholder="T-Shirt Size">
                <label for="tshirt" class="form-label text-muted">T-Shirt Size</label>
                <datalist id="sizes">
                    <option value="S">
                    <option value="M">
                    <option value="L">
                    <option value="XL">
                    <option value="XXL">
                    <option value="3XL">
                    <option value="4XL">
                </datalist>
                <small class="text-danger d-none">* Please select T-shirt size</small>
            </div>

            <div class="mb-4 mt-2 form-floating">
                <input type="text" name="tshirt_number" id="tshirt_number" onkeypress="return isNumberKey(this, event);" maxlength="4" class="form-control" placeholder="T-Shirt Number">
                <label class="form-label text-muted">T-Shirt Number</label>
                <small class="text-danger d-none">* Please enter T-Shirt Number</small>
            </div>

            <!-- profile preview -->
            <div class="preview-pic row mx-0 d-none">
                <p class="d-block mb-0 py-2 text-center bg-black text-white" style="background-image: linear-gradient(var(--color2) 40%, #000);">This is how your profile will look on the Auction screen</p>
                <div class="preview-pic-div justify-content-center d-flex flex-column" style="background-image:url('<?= ROOT . '/public/assets/images/files/auction_background.jpg?v=' . $updated ?>')">
                    <p class="p-name d-block text-warning fw-bold text-uppercase text-center fs-4 mt-2"></p>
                    <div class="w-100 d-block text-center mb-3">
                        <img id="image_preview" class="rounded-pill border border-warning border-3 oveflow-hidden shadow-lg w-50" style="aspect-ratio: 1/1; max-width:300px" src="">
                    </div>

                    <p class="d-block text-center text-white fw-normal text-uppercase">
                        <span class="p-role d-none d-inline-block px-2 mb-2 text-light lh-lg shadow-lg me-1" style="background-image: linear-gradient(#19b904 12%,#125109 60%);"></span>
                        <span class="p-bat d-none d-inline-block shadow-lg mb-2 text-light px-1 lh-lg" style="background-image: linear-gradient(#0d6efd 12%,#0f2c57  60%);">
                            <img src="<?= ROOT . '/public/assets/images/files/bat.png?v=' . $updated ?>" class="auction_style mx-2">
                            <b class="fw-normal"></b>
                        </span><span class="p-ball d-inline-block d-none shadow-lg mb-2 text-light px-1 lh-lg ms-1" style="background-image: linear-gradient(#0d6efd 12%,#0f2c57  60%);">
                            <img src="<?= ROOT . '/public/assets/images/files/ball.png?v=' . $updated ?>" class="auction_style mx-1">
                            <b class="fw-normal"></b>
                        </span>
                        <span class="p-town d-none d-inline-block ms-1 mb-2 shadow-lg text-light ms-0 px-2 lh-lg" style="background-image: linear-gradient(#6c757d 12%,#2d3033 60%);">
                            <icon class="me-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-geo-alt-fill mb-1" viewBox="0 0 16 16">
                                    <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"></path>
                                </svg>
                            </icon>
                            <b class="fw-normal"></b>
                        </span>
                    </p>
                </div>

            </div>
            <center>
                <button type="submit" name="submit" class="submit btn btn-primary bg-theme border-0 fw-bold px-5 my-4 py-3 rounded-pill">Register Now!</button>
            </center>
        </form>

    </div><br><br><br><br><br>
    <!--/Registration-->



</div>

<style>
    body {
        background-image: linear-gradient(var(--color2) 40%, #e7e7e7);
    }

    .text-theme {
        color: var(--color2) !important;
    }

    .bg-theme {
        background-color: var(--color2) !important
    }

    .border-theme {
        border-color: var(--color2) !important
    }

    .auction_style {
        max-height: 20px;
        margin-bottom: 6px;
    }
</style>

<script>
    // declaration
    let check = 0; // for form validation
    let batting = document.querySelector(".form-select[name='batting_style']");
    let bowling = document.querySelector(".form-select[name='bowling_style']");
    let role = document.querySelector(".form-select[name='role']");
    let name = document.querySelector(".form-control[name='name']");
    let phone = document.querySelector(".form-control[name='phone']");
    let tshirt_number = document.querySelector(".form-control[name='tshirt_number']");
    let town = document.querySelector(".form-control[name='town']");
    let image = document.querySelector(".form-control[name='image']");

    // functions
    const errorON = e => {
        e.parentElement.querySelector('small').classList.remove('d-none');
        e.classList.add('border-danger');
        e.focus();
        flag = 1;
    }

    const errorONSelect = e => {
        e.parentElement.querySelector('small').classList.remove('d-none');
        e.classList.add('border-danger');
        e.focus();
        flag = 1;
    }

    const errorOFF = e => {
        e.classList.remove('border-danger');
        e.parentElement.querySelector('small').classList.add('d-none');
        flag = 0;
    }

    const errorOFFSelect = e => {
        e.target.classList.remove('border-danger');
        e.target.parentElement.querySelector('small').classList.add('d-none');
        flag = 0;
    }

    const nameCheck = () => {
        name.value.trim() == '' || name.value.trim().length <= 2 ? errorON(name) : errorOFF(name);
        document.querySelector(".p-name").innerHTML = name.value;
    };

    const imageCheck = () => {
        image.value == '' ? errorON(image) : errorOFF(image);
    }

    const inputCheck = () => document.querySelectorAll('.inputs').forEach(i => i.value.trim() == '' ? errorON(i) : errorOFF(i));

    const selectsCheck = e => e.value == '' ? errorONSelect(e) : errorOFFSelect(e);

    const phoneCheck = () => phone.value.trim().length < 9 ? errorON(phone) : errorOFF(phone);

    const tshirtNumberCheck = () => tshirt_number.value == '' ? errorON(tshirt_number) : errorOFF(tshirt_number);

    const selectFieldsCheck = () => {
        let selectCheck = 0
        document.querySelectorAll('select').forEach(s => {
            if (!s.parentElement.classList.contains('d-none')) {
                if (s.value == '') {
                    selectCheck++;
                    selectsCheck(s);
                    return false;
                }
            }
        });
        check = selectCheck == 0 ? 1 : 0;
    }

    // role selection
    role.addEventListener("change", () => {

        // set both batting & bowling to blank
        bowling.value = "";
        batting.value = "";

        document.querySelector(".p-role").classList.remove('d-none');
        document.querySelector(".p-role").innerHTML = role.value;

        // Batsman or Wicket-Keeper
        if (role.value == "Batsman" || role.value == "Wicket Keeper") {
            batting.parentElement.classList.remove("d-none");
            bowling.parentElement.classList.add("d-none");
            document.querySelector(".p-bat").classList.remove('d-none');
            document.querySelector(".p-ball").classList.add('d-none');
        }
        // Bowler
        else if (role.value == "Bowler") {
            bowling.parentElement.classList.remove("d-none");
            batting.parentElement.classList.add("d-none");
            document.querySelector(".p-bat").classList.add('d-none');
            document.querySelector(".p-ball").classList.remove('d-none');
        }
        // All-Rounder 
        else if (role.value == "All Rounder") {
            batting.parentElement.classList.remove("d-none");
            bowling.parentElement.classList.remove("d-none");
            document.querySelector(".p-bat").classList.remove('d-none');
            document.querySelector(".p-ball").classList.remove('d-none');
        }
    });

    // batting-bowling-town change
    batting.addEventListener("change", () => document.querySelector(".p-bat b").innerHTML = batting.value);
    bowling.addEventListener("change", () => document.querySelector(".p-ball b").innerHTML = bowling.value);
    // town.addEventListener("input", () => {
    //     document.querySelector(".p-town").classList.remove('d-none');
    //     document.querySelector(".p-town b").innerHTML = town.value;
    // });

    // player preview
    document.querySelector("#image").addEventListener("change", e => {

        const imageFile = image.files[0];
        const validImage = ['png', 'jpeg', 'jpg'];
        const imageSizeLimit = "<?= floor((int)$setting->photo_size / 1048576) ?>";
        const clientSize = Math.floor(imageFile.size / 1048576);
        let ext = imageFile.type.split('/')[1].toLowerCase();

        if (!validImage.includes(ext)) { // extention check
            alert(`<p class="bg-danger py-2 text-center text-white rounded fs-5">Incorrect File Format</p><b>${imageFile.name}</b> is not a valid Photo. <br>Valid formats are PNG, JPG & JPEG.`);
            image.value = '';
            imageCheck();
        } else if (imageFile.size >= <?= $setting->photo_size ?>) {
            alert(`<p class="bg-danger py-2 text-center text-white rounded fs-5">File Size Error</p>Your Photo size is <b class="text-danger">${clientSize} MB</b>, that is too big.<br>Upload size limit is <b>${imageSizeLimit} MB</b>.`);
            image.value = '';
            imageCheck();
        } else {
            image_preview.src = URL.createObjectURL(imageFile);
            document.querySelector('.preview-pic').classList.remove('d-none');
        }
    });

    // sample image
    document.querySelector('sample').addEventListener('click', () => {
        alert(`<img src="<?= ROOT . '/public/assets/images/files/default_player.jpg?v=' . $updated ?>" class="img-fluid shadow rounded border">`)
    });


    // fields validation
    name.addEventListener('input', nameCheck);
    role.addEventListener('change', e => selectsCheck(e));
    !batting_style.parentElement.classList.contains('d-none') && batting_style.addEventListener('change', e => selectsCheck(e));
    !bowling_style.parentElement.classList.contains('d-none') && bowling_style.addEventListener('change', e => selectsCheck(e));
    phone.addEventListener('input', phoneCheck);
    //tshirt_number.addEventListener('input', tshirt_number);

    // form submit
    function validate() {

        // fields check                           
        //inputCheck();
        phoneCheck();
        //tshirtNumberCheck();
        selectFieldsCheck();
        !batting_style.parentElement.classList.contains('d-none') && batting_style.addEventListener('change', e => selectsCheck(e));
        !bowling_style.parentElement.classList.contains('d-none') && bowling_style.addEventListener('change', e => selectsCheck(e));
        nameCheck();
        imageCheck();

        // proceed to submit if all ok
        if (check == 1) {
            document.querySelector('.submit').innerHTML = 'Submitting...';
            return true;
        } else {
            return false;
        }
    }
</script>

<?php $this->view('front/inc/footer', $data); ?>