<?php

namespace App\models;

use App\core\Model;

defined("ROOTPATH") or die("Access Denied!");

class Player
{

    use Model;

    protected $table = 'players';
    protected $primaryKey = 'id';
    protected $allowedColumns = [
        'date',
        'name',
        'role',
        'batting_style',
        'bowling_style',
        'town',
        'tshirt_size',
        'tshirt_number',
        'phone',
        'image',
        'status',
        'price',
        'team_id',
        'position',
        'active'
    ];

}
