<?php

namespace App\models;

use App\core\Model;

defined("ROOTPATH") or die("Access Denied!");

class User
{

    use Model;

    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedColumns = [
        'name',
        'username',
        'role',
        'password'
    ];

}
