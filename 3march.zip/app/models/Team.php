<?php

namespace App\models;

use App\core\Model;

defined("ROOTPATH") or die("Access Denied!");

class Team
{

    use Model;

    protected $table = 'teams';
    protected $primaryKey = 'id';
    protected $allowedColumns = [
        'timestamps',
    ];

}
