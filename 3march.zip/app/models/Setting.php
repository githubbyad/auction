<?php

namespace App\models;

use App\core\Model;

defined("ROOTPATH") or die("Access Denied!");

class Setting
{

    use Model;

    protected $table = "setting";
    protected $allowedColumns = [
        'logo',
        'allow_auction_menus',
        'registration',
        'refresh',
        'town_option',
        'photo_width',
        'photo_size',
        'always_on_mobile',
        'auto_active'
    ];

}
