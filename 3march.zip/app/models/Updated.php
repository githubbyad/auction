<?php

namespace App\models;

use App\core\Model;

defined("ROOTPATH") or die("Access Denied!");

class Updated
{

    use Model;

    protected $table = 'updated';
    protected $primaryKey = 'id';
    protected $allowedColumns = [
        'timestamp'
    ];

}
