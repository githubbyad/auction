// restrict only numbers in input field
function isNumberKey(txt, evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode == 46) {
        //Check if the text already contains the . character
        if (txt.value.indexOf('.') === -1) {
            return true;
        } else {
            return false;
        }
    } else {
        if (charCode > 31 &&
            (charCode < 48 || charCode > 57))
            return false;
    }
    return true;
}

// restrict only numbers in input field
function isPhoneNumber(txt, evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode == 46) {
        return false;
    } else {
        if (charCode > 31 &&
            (charCode < 48 || charCode > 57))
            return false;
    }
    return true;
}

function alert(msg, ctl) {
    if (!document.getElementById('f_alert_button')) {
        document.getElementsByTagName("body")[0].insertAdjacentHTML("beforeend", "<button id='f_alert_button' type='button' data-bs-toggle='modal' data-bs-target='#f_alert' style='display:none;'></button><div class='f_alert_box modal fade' id='f_alert' data-bs-backdrop='static' data-bs-keyboard='false' tabindex='-1' aria-labelledby='f_alertLabel' aria-hidden='true'><div class='modal-dialog modal-dialog-centered modal-dialog-scrollable'><div class='modal-content'><div class='modal-header' style='display:none'><button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button></div><div class='modal-body text-center' style='white-space: pre-wrap;'>" + msg + "</div><div class='modal-footer d-flex justify-content-center border-0'><button type='button' class='f_alert_close btn btn-dark py-2 px-4' data-bs-dismiss='modal'>OK</button></div></div></div><style>@media (min-width:576px){.modal-dialog{max-width:400px}}</style></div>");
        setTimeout(() => document.getElementById('f_alert_button').click(), 500);
        document.getElementsByClassName('f_alert_close')[0].addEventListener('click', function () {
            document.getElementById('f_alert_button').remove();
            document.getElementsByClassName('f_alert_box')[0].remove();
        });
    }
}

function confirmdelete(msg, item, link) {
    if (!document.getElementById('f_confirm_delete_button')) {
        document.getElementsByTagName("body")[0].insertAdjacentHTML(`beforeend`, `
            <button id='f_confirm_delete_button' type='button' data-bs-toggle='modal' data-bs-target='#f_confirm_delete' style='display:none;'></button>
            <div class='f_confirm_delete_box modal fade' id='f_confirm_delete' data-bs-backdrop='static' data-bs-keyboard='false' tabindex='-1' aria-labelledby='f_confirm_deleteLabel' aria-hidden='true'>
                <div class='modal-dialog modal-dialog-centered modal-dialog-scrollable'>
                    <div class='modal-content'>
                        <div class='modal-header' style='display:none'>
                            <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                        </div>
                        <div class='modal-body text-center' style='white-space: pre-wrap;'>${msg}</div>
                        <div class='modal-body text-center fw-bold py-1' style='white-space: pre-wrap;'>${item}</div>
                        <div class='modal-footer d-flex justify-content-center border-0'>
                            <button type='button' class='f_confirm_delete_yes btn btn-danger me-3 py-2 px-4' data-bs-dismiss='modal'>Delete</button>
                            <button type='button' class='f_confirm_delete_close btn btn-dark py-2 px-4' data-bs-dismiss='modal'>Cancel</button>
                        </div>
                    </div>
                </div>
                <style>@media (min-width:576px){.modal-dialog{max-width:400px}}</style>
            </div>
        `);
        document.getElementById('f_confirm_delete_button').click();
        document.getElementsByClassName('f_confirm_delete_close')[0].addEventListener('click', function () {
            document.getElementById('f_confirm_delete_button').remove();
            document.getElementsByClassName('f_confirm_delete_box')[0].remove();
        });
        document.getElementsByClassName('f_confirm_delete_yes')[0].addEventListener('click', function () {
            document.getElementById('f_confirm_delete_button').remove();
            document.getElementsByClassName('f_confirm_delete_box')[0].remove();
            window.location.href = link;
        });
    }
    return false;
}

// biding values
function getBid() {
    return [
        500,
        750,
        1000,
        1250,
        1500,
        1750,
        2000,
        2500,
        3000,
        3500,
        4000,
        4500,
        5000,
        6000,
        7000,
        8000,
        9000,
        10000,
        11000,
        12000,
        13000,
        14000,
        15000,
        16000,
        17000,
        18000,
        19000,
        20000,
        21000,
        22000,
        23000,
        24000,
        25000,
        26000,
        27000,
        28000,
        29000,
        30000,
        31000,
        32000,
        33000,
        34000,
        35000,
        36000,
        37000,
        38000,
        39000,
        40000,
        41000,
        42000,
        43000,
        44000,
        45000,
        46000,
        47000,
        48000,
        49000,
        50000,
    ];
}

function getHighestBid() {
    const bid = getBid();
    return bid[getBid().length - 1];
}