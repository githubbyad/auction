// for mobile
if(window.screen.width <= 500) {
    document.body.classList.add('mobile');
  }

// set menus height
document.querySelector(".auction_menu_list").style.height = window.innerHeight + "px";

// menu icon click
document.querySelector(".auction_menu").addEventListener("click", () => {
    document.querySelector(".auction_menu_list").classList.toggle("menu_slide");
    document.querySelector(".header_auction").classList.toggle("position-fixed");
    document.querySelector(".auction_div").classList.toggle("auction_blur");
    document.querySelector(".auction_logo").classList.toggle("invisible");
    document.body.classList.toggle("overflow-hidden");
    document.querySelector(".ac_bar").classList.toggle("d-none");
    document.querySelector(".ac_close").classList.toggle("d-none");
    document.querySelectorAll('.auction_menu_li').forEach((m, i) => {
        t = 100 * (i + 1);
        if (m.classList.contains('auction_menu_li_show')) {
            m.classList.remove('auction_menu_li_show');
        } else {
            setTimeout(() => {
                m.classList.add('auction_menu_li_show');
            }, t);
        }
    });
});

// menu and sub-menu click to close menu bar
document.querySelectorAll(".link").forEach(l => {
    l.addEventListener("click", () => {
        document.querySelector(".auction_menu").click();
    });
});

// menu click to open submenus
document.querySelectorAll(".auction_menu_ul").forEach(s => {
    s.addEventListener("click", () => {
        s.nextElementSibling.classList.toggle("d-none");
    });
});

// Menu Scroll on mobile
// if (window.screen.width < 768) {
//     window.onscroll = function (e) {
//         if (this.oldScroll > this.scrollY) {
//             console.log('Up');
//             // Scroll Up
//             if (window.scrollY > 150) {
//                 document.querySelector(".header_auction").classList.remove("transform_up");
//                 document.querySelector(".header_auction").classList.add("auction_up");
//                 document.querySelector(".auction_menu_list").classList.add("auction_up");
//                 document.querySelector(".header_auction").classList.add("auction_up_color");
//             } else {
//                 document.querySelector(".header_auction").classList.remove("auction_up");
//                 document.querySelector(".auction_menu_list").classList.remove("auction_up");
//                 document.querySelector(".header_auction").classList.remove("auction_up_color");
//             }
//             if (window.scrollY <= 149) {
//                 document.querySelector(".header_auction").classList.add("transform_up");
//             }
//             if (window.scrollY <= 100) {
//                 document.querySelector(".header_auction").classList.remove("transform_up");
//             }
//         } else {
//             console.log('Down');
//             // Scroll Down
//             document.querySelector(".header_auction").classList.add("transform_up");
//             document.querySelector(".header_auction").classList.remove("auction_up");
//             document.querySelector(".auction_menu_list").classList.remove("auction_up");
//             document.querySelector(".header_auction").classList.remove("auction_up_color");
//         }
//         this.oldScroll = this.scrollY;
//     }
// }